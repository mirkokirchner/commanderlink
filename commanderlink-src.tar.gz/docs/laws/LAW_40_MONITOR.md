# LAW_40_MONITOR.md
## CommanderLink – Monitor-, Beobachtungs- & Read-Only-Gesetz

### Status
VERBINDLICH · NORMATIV · FREIGABEPFLICHTIG

---

## 1. Monitor ist passiv

Monitor liest, niemals schreibt.

---

## 2. Monitor ist vollständig

Alles Relevante ist sichtbar.

---

## 3. Monitor ist ehrlich

Keine Glättung, keine Verschleierung.

---

## 4. Schlussformel

Der Monitor lügt nie.

