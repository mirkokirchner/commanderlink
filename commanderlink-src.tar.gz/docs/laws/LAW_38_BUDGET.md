# LAW_38_BUDGET.md
## CommanderLink – Budget-, Quoten- & Selbstbegrenzungs-Gesetz

### Status
VERBINDLICH · NORMATIV · FREIGABEPFLICHTIG

---

## 1. Budget ist Pflicht

CommanderLink operiert ausschließlich innerhalb expliziter Budgets.

- CPU
- Memory
- I/O
- Netzwerk

---

## 2. Eigenbudget zuerst

Bei Knappheit wird **zuerst CL selbst reduziert**.

---

## 3. Budget ist hart

Budgetüberschreitung erzwingt Degradation.

---

## 4. Budget ist messbasiert

Schätzung ist verboten.

---

## 5. Schlussformel

Budget ist Selbstdisziplin.
Ohne Budget ist Symbiose unmöglich.

