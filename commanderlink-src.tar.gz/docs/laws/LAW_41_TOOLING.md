# LAW_41_TOOLING.md
## CommanderLink – Tool-, Prüf- & Ableitungs-Gesetz

### Status
VERBINDLICH · NORMATIV · FREIGABEPFLICHTIG

---

## 1. Tools beweisen Gesetze

Tools sind keine Komfortprogramme.

---

## 2. Tools verändern nichts

Read-only oder Build-time only.

---

## 3. Tools sind verpflichtend

Kein Tool → kein Beweis → ungültig.

---

## 4. Schlussformel

Ohne Tools keine Wahrheit.

