#ifndef CL_MONITOR_INPUT_H
#define CL_MONITOR_INPUT_H
void monitor_handle_input(int key);
#endif
