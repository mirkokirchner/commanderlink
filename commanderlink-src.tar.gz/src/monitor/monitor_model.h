#ifndef CL_MONITOR_MODEL_H
#define CL_MONITOR_MODEL_H

#include "monitor_state.h"

void ui_model_update_from_shm(cl_monitor_state_t *st);

#endif

