#pragma once
#ifdef __cplusplus
extern "C" {
#endif

#include "cl_oob_wire.h"

#ifdef __cplusplus
}
#endif

