# cl_shm_dump

CLI-Tool zur Prüfung des CommanderLink Core-SHM.

## Zweck
- Root lesen (Host-Order)
- TOC iterieren
- Segmentübersicht ausgeben

## Build
Wird später per Makefile-Target eingebunden.

## Lauf
- benötigt laufenden Core/Dummy-SHM, der `/cl_core_root` erstellt.

